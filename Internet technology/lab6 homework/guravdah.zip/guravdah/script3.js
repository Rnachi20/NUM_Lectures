var el_down = document.getElementById("result");
var inputF = document.getElementById("message");
  
        function myFunction() {
            el_down.innerHTML = 
                  inputF.value;
        }